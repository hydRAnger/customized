#!/usr/bin/perl
use strict;
use warnings;

my $ANI=$ARGV[0];
my $out=$ARGV[1];

open(FILE,"$ANI")||die "Can't open FILE $ANI\n";
my @line=<FILE>;
my $num=@line-1;
open(OUT,">$out");
print OUT "$num\n";
my $name=shift @line;
my @name=split"\t",$name;
my %name;
my $t;
foreach my $line (@line) {
	my @a=split"\t",$line;
	$t=@a;
	$name{$a[0]}++;
}
foreach my $line (@line) {
	my @a=split"\t",$line;
	my $name=$a[0];
	if(length($a[0])>30){my @name=split"_",$a[0];
	my $n=@name;
	$name=substr($name[0],0,1)."_".$name[1];
	my @d=split"__",$a[0];
	$name=$name."_".pop @d;
	}
	print OUT "$name\t";
	foreach (1..($t-1)) {
		unless(exists $name{$name[$_]}){next;}
		if ($a[$_]=~/[0-9a-zA-Z]/) {
			$a[$_]=(1-$a[$_]);
		}else{
			$a[$_]=-99;   ###��-99��������
		}
		print OUT "$a[$_]\t";
	}
	print OUT "\n";
}