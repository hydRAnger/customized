#!/usr/bin/perl
use strict;
use warnings;

my $ANI=$ARGV[0];
my $out=$ARGV[1];

open(FILE,"$ANI")||die "Can't open FILE $ANI\n";
my @line=<FILE>;
my $num=@line-1;
open(OUT,">$out");
#print OUT "$num\n";
shift @line;
foreach my $line (@line) {
	my @a=split"\t",$line;
	print OUT "$a[0]\t";

	foreach (1..$num) {
		if ($a[$_]=~/[0-9a-zA-Z]/) {
			$a[$_]=(1-$a[$_]);
		}else{
			$a[$_]=-99;   ###��-99��������
		}
		print OUT "$a[$_]\t";
	}
	print OUT "\n";
}