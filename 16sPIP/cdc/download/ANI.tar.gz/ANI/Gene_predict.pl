#!/usr/bin/perl

=head1 Name

=head1 Description

=head1 

  Author: zhangwen, zhangwen@icdc.cn
  Version: 1.0, Date: 2015-02-01

=head1 Usage:

perl  Gene_predict.pl -I genome.fa -O ./ 

=head1 Example

=cut
use strict;
use Getopt::Long;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname); 
use Data::Dumper;
use warnings;
use Pod::Text;
use Term::ANSIColor qw(:constants);
$Term::ANSIColor::AUTORESET=1;
##get options from command line into variables and set default values
###-----------------Time record-----------------------------###
my $Time_Start = sub_format_datetime(localtime(time())); #......
my $Data_Vision = substr($Time_Start,0,10);
my ($genome,$outdir,$genus,$species,$tag,$HELP);
GetOptions(
		"I:s"=>\$genome,
		"O:s"=>\$outdir,
		"Tag:s"=>\$tag,
		"help"=>\$HELP
);
die `pod2text $0` if ($HELP || !defined $genome || !defined $tag ||!defined $outdir);


my %config;
parse_config("$Bin/config.txt",\%config);
my $glimmer=$config{glimmer};
my $glimmer_csh=$config{glimmer_csh};
##Glimmer ����Ԥ��
system "mkdir $outdir/glimmer\n";
print "sh $Bin/glimmer_train.sh $glimmer linear $genome $outdir/glimmer/$tag $glimmer_csh\n";
system "sh $Bin/glimmer_train.sh $glimmer linear $genome $outdir/glimmer/$tag $glimmer_csh\n";
print "$glimmer -o50 -g110 -t30 -l $genome $outdir/glimmer/$tag.icm  $outdir/glimmer/$tag\n";
system "$glimmer  -o50 -g110 -t30 -l $genome $outdir/glimmer/$tag.icm  $outdir/glimmer/$tag\n";
print "perl $Bin/predict_convert.pl --predict glimmer  --finalname $tag --log --verbose $outdir/glimmer/$tag.predict $genome\n";
system "perl $Bin/predict_convert.pl --predict glimmer  --finalname $tag --log --verbose $outdir/glimmer/$tag.predict $genome\n";




my $Time_End= sub_format_datetime(localtime(time()));
print "Running from [$Time_Start] to [$Time_End]\n";



#====================================================================================================================
#  +------------------+
#  |   subprogram     |
#  +------------------+



sub sub_format_datetime #.....
{
    my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
	$wday = $yday = $isdst = 0;
    sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon, $day, $hour, $min, $sec);
}
#####
sub gc{
	my $seq=shift @_;
	my $gc=$seq=~tr/(G|C|g|c)/(G|C|g|c)/;
	my $l=length($seq);


	return ($gc,$l);
}

##parse the software.config file, and check the existence of each software
####################################################
sub parse_config{
	my $conifg_file = shift;
	my $config_p = shift;
	
	my $error_status = 0;
	open IN,$conifg_file || die "fail open: $conifg_file";
	while (<IN>) {
		next if(/#/);
		if (/(\S+)\s*=\s*(\S+)/) {
			my ($software_name,$software_address) = ($1,$2);
			$config_p->{$software_name} = $software_address;

		}
	}
	close IN;
	die "\nExit due to error of software configuration\n" if($error_status);
}