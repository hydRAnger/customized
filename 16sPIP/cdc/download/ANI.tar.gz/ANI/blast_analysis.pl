#!/usr/bin/perl
=head1 Name

=head1 Description

=head1 Version1.0

  Author: Wen Zhang
  Version: 1.0, Date: 2011/04/25

=head1 Usage:ɸѡblast���
              Usage:
                 perl $0 [options] -Input <blast> -Output <output>\n);

=cut
use strict;
use Getopt::Long;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
#use Data::fumper;
#use warnings;
use Pod::Text;
use Term::ANSIColor qw(:constants);



sub Usage{
        print qq(
                Usage:
                 perl $0 [options] -Input <blast> -Output <output>\n);
}

####������ȡ
my %config;
parse_config("$Bin/config.txt",\%config);
my $blast=$config{blast};
my $program=$config{ANItools};

#### Parameters
my ($evalue,$iden,$positive,$len,$len2,$Help,$file,$output,$start,$end);

GetOptions(
        "E:f"=>\$evalue,   #Evalue
        "I:f"=>\$iden, #Identity
        "P:f"=>\$positive, #Positive
        "L:f"=>\$len,     #len cut of
        "L2:f"=>\$len2,   #len% cut off
		"Start:f"=>\$start,   #Start site on chromosome
		"End:f"=>\$end,     #End site on chromosome
        "help:s"=>\$Help,
		"Input:s"=>\$file,
		"Output:s"=>\$output,
);
die `pod2text $0` if ($Help || !defined $file || !defined $output);
#print "Identity,$iden\n";

####blast parser
my $parser=$file.".parser";
system "perl $program/blast_parser.pl $file >$parser";
####

#print "$file\n";
open(FILE,"$parser")||die;
my $out1=$parser."_Genome.csv";

unless(-e "$output/blast"){system "mkdir $output/blast\n";}
my $query_len;
my $align_len;
my $identity;
my %query_len;
my %align_len;
my %identity;
while (<FILE>) {
		chomp;
		my $line=$_;
		my @a=split"\t",$line;
		if($a[0]=~/Query/){next;}
		my $q_len=$a[1];
		my $i=$a[8];
		my $p=$a[9];
		my $align=$a[11];
		my $q_anno=$a[14];
		my $t_anno=$a[15];
		$q_len=~s/\,//;
		$align=~s/\,//;
		#unless($identity=~/\d/ && $positive=~/\d/){print "$identity,$positive,$align,$q_len,$line\n"};
		unless($q_len>0){next;}
				#print "$i,$align,$q_len,$line\n";
		if(defined $iden){unless($i>=$iden){next;}}
		#print "$i,$align,$q_len,$line\n";
		if(defined $len2){unless(($align/$q_len)>=$len2){next;}}
		if(defined $len){unless($align>=$len){next;}}
		if(defined $start && defined $end){unless($a[6]>=$start && $a[7]<=$end){next;}}
		if(defined $p){unless($p eq "--" ||  $p>=$positive){next;}}
		if(exists $identity{$a[0]} and $identity{$a[0]}>($align*$i)){next;} #�ų��ظ�����
		$query_len+=$q_len;
		$align_len+=$align;
		$identity+=$align*$i;
		$query_len{$a[0]}+=$q_len;
		$align_len{$a[0]}+=$align;
		$identity{$a[0]}+=$align*$i;
}
 ###�ų�Ⱦɫ��������ȶԵ����
 #print "$align_len,$query_len,$out1\n";

 unless(($align_len/$query_len)>=0.5){
	 print ERROR "$file,$align_len,$query_len\n";
	 system "rm $file\n";
	system "rm $parser\n";
	system "rm $file.filterror\n";
	 next;}
open(OUT,">$out1");

 ##������
 my $basename=basename($file);
 my @a=split"\\.",$basename;

 print OUT "Query_Gnenome_ID,Target_Genome_ID,Sum_query_len,Sum_align_len,Align%,Avg_identity\n";
 my $align=$align_len/$query_len;
 my $i=$identity/$align_len;
 print OUT "$a[0],$a[1],$query_len,$align_len,$align,$i\n";

 print "ANI value is $i\n";
my @g=sort keys %query_len;
#print OUT2 "Query_Genome_ID,Target_Genome_ID,Gene_ID,Gene_len,Align_len,Align%,Avg_Identity\n";


system "rm $file\n";
system "rm $file.filterror\n";
system "cat $out1 >>$output/Genome.csv";





sub parse_config{
	my $conifg_file = shift;
	my $config_p = shift;
	
	my $error_status = 0;
	open IN,$conifg_file || die "fail open: $conifg_file";
	while (<IN>) {
		next if(/#/);
		if (/(\S+)\s*=\s*(\S+)/) {
			my ($software_name,$software_address) = ($1,$2);
			$config_p->{$software_name} = $software_address;

		}
	}
	close IN;
	die "\nExit due to error of software configuration\n" if($error_status);
}