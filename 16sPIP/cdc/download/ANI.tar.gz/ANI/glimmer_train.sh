#!/bin/sh
##..........<1Mb,....................
##This pipeline train and predict genes on the same genome sequences.
##The input file can be multi-fasta format.
##Note that if you have both the genome and plasmid sequence, and you think they are quite different, please don't put them together for predicting genes.
##Note that the linear and circular chromosmes are different
if [ $# -lt 4 ]; then
echo "Usage: $0 <glimmer_bin> <linear|circular> <sequence.fa> <result_tag>"
echo "Example: glimmer_train.sh  /share/raid1/genome/biosoft/glimmer3.02/bin circular ../input/Bacillus_sphaericus_genome.fa ./Bacillus_sphaericus"
exit
fi
##inuput file is the genome sequence file in fasta format
##step the home directory of glimmer software package
##tagname is the prefix part of all the result files
softpath=$1
topology=$2
seqfile=$3
tagname=$4
csh=$5
##seqfile is multi-fasta fasta, wholefile combines all the sequences into one sequence fasta format
wholefile=$tagname.whole
## Because the long-orfs program can only accept one-sequnce-fasta format
## So generate a combined sequence file which represent the whole sequence set
echo ">genome" > $wholefile
more $seqfile  | perl -ne 'print $_ if(!/^>/);' >> $wholefile
$csh $wholefile $tagname
## run long-orfs
$softpath/long-orfs -n -t 1.15 $wholefile $tagname.longorfs  1>/dev/null 2>/dev/null
$softpath/extract -t $wholefile $tagname.longorfs > $tagname.train  2>/dev/null
## build gene models with training materials
$softpath/build-icm -r $tagname.icm < $tagname.train 1>/dev/null 2>/dev/null
