#!/usr/bin/perl
###��Distanceת����NJtree��nwk�ļ���svg�ļ�
###ע��ֻ���������޿����ݵ�Distance
use strict;
use warnings;
use lib "/share/nas3/zhangwen/bin/lib/perl5/";
use Bio::Perl;
use Bio::Tree::DistanceFactory;
use Bio::Matrix::IO;
use Bio::TreeIO;



my $distance=$ARGV[0];
my $out=$ARGV[1];


my $dfactory = Bio::Tree::DistanceFactory->new(-method => 'NJ');


my $parser = Bio::Matrix::IO->new(-format => 'phylip',
                                   -file   => $distance);
 my $mat  = $parser->next_matrix;
 my $tree = $dfactory->make_tree($mat);
my $treeout = Bio::TreeIO->new(-format => 'newick',
                           -file   => ">$out");
$treeout->write_tree($tree);


